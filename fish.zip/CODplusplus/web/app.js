const apps = [
  ["firefox","Firefox","browser","🦊","Fast, privacy-focused web browser."],
  ["chromium","Chromium","browser","🌐","Open-source Chromium browser."],
  ["brave","Brave","browser","🦁","Privacy-focused Chromium browser."],
  ["vscode","VS Code","development","💻","Full-featured source-code editor."],
  ["vscodium","VSCodium","development","📝","Community-built VS Code binaries."],
  ["git","Git","development","🔀","Distributed version control."],
  ["gh","GitHub CLI","development","🐙","GitHub from the terminal."],
  ["nodejs","Node.js","development","⬢","JavaScript runtime and npm."],
  ["python","Python","development","🐍","Python 3 development environment."],
  ["java","Java","development","☕","OpenJDK development environment."],
  ["gcc","GCC/G++","development","⚙️","C/C++ compiler toolchain."],
  ["clang","Clang","development","🔧","LLVM C/C++ compiler."],
  ["rust","Rust","development","🦀","Rust compiler and Cargo."],
  ["go","Go","development","🐹","Go programming language."],
  ["neovim","Neovim","development","⌨️","Modern terminal editor."],
  ["tmux","tmux","development","🖥️","Terminal multiplexer."],
  ["btop","btop","utility","📊","Interactive system monitor."],
  ["htop","htop","utility","📈","Interactive process viewer."],
  ["ripgrep","ripgrep","utility","🔎","Fast recursive text search."],
  ["fd","fd","utility","📂","Fast find alternative."],
  ["tree","tree","utility","🌳","Directory tree viewer."],
  ["jq","jq","utility","{}","Command-line JSON processor."],
  ["unzip","Unzip","utility","📦","ZIP archive utility."],
  ["p7zip","7-Zip","utility","🗜️","Archive utility."],
  ["curl","curl","utility","↔️","HTTP and transfer utility."],
  ["wget","wget","utility","⬇️","Command-line downloader."],
  ["gimp","GIMP","creative","🎨","Image editor."],
  ["krita","Krita","creative","🖌️","Digital painting application."],
  ["inkscape","Inkscape","creative","✒️","Vector graphics editor."],
  ["blender","Blender","creative","🧊","3D creation suite."],
  ["audacity","Audacity","creative","🎙️","Audio editor and recorder."],
  ["kdenlive","Kdenlive","creative","🎬","Non-linear video editor."],
  ["obs","OBS Studio","creative","📹","Screen recording and production."],
  ["libreoffice","LibreOffice","productivity","📄","Office suite."],
  ["vlc","VLC","productivity","▶️","Media player."],
  ["okular","Okular","productivity","📕","PDF/document viewer."],
  ["wireshark","Wireshark","networking","🦈","Network protocol analyzer."],
  ["nmap","Nmap","networking","🛰️","Network discovery and auditing utility."],
  ["openssh","OpenSSH","networking","🔐","SSH client tools."],
  ["traceroute","Traceroute","networking","🧭","Network path diagnostic."],
  ["dnsutils","DNS Utilities","networking","🌎","DNS lookup tools."],
  ["prismlauncher","Prism Launcher","gaming","⛏️","Minecraft launcher."],
  ["heroic","Heroic Games Launcher","gaming","🎮","Game launcher for supported stores."],
  ["lutris","Lutris","gaming","🕹️","Game launcher and manager."],
  ["wine","Wine","gaming","🍷","Windows compatibility layer."]
];

const categories = ["all","browser","development","utility","creative","productivity","networking","gaming"];
let active = "all";
let query = "";
const installed = new Set(JSON.parse(localStorage.getItem("codpp-installed") || "[]"));

const catEl = document.querySelector("#categories");
const appsEl = document.querySelector("#apps");
const countEl = document.querySelector("#count");
const titleEl = document.querySelector("#sectionTitle");
const searchEl = document.querySelector("#search");
const toast = document.querySelector("#toast");

function label(x) { return x[0].toUpperCase()+x.slice(1); }

function renderCategories() {
  catEl.innerHTML = categories.map(c =>
    `<button class="cat ${active===c?"active":""}" data-cat="${c}">${c==="all"?"All":label(c)}</button>`
  ).join("");
  catEl.querySelectorAll(".cat").forEach(b => b.onclick = () => {
    active = b.dataset.cat; renderCategories(); render();
  });
}

function render() {
  const filtered = apps.filter(a =>
    (active === "all" || a[2] === active) &&
    `${a[1]} ${a[2]} ${a[4]}`.toLowerCase().includes(query.toLowerCase())
  );
  titleEl.textContent = active === "all" ? "All Apps" : label(active);
  countEl.textContent = `${filtered.length} app${filtered.length===1?"":"s"}`;
  appsEl.innerHTML = filtered.map(a => {
    const isInstalled = installed.has(a[0]);
    return `<article class="card">
      <div class="app-icon">${a[3]}</div>
      <h3>${a[1]}</h3>
      <p>${a[4]}</p>
      <div class="meta">
        <span class="tag">${a[2]}</span>
        <button class="install ${isInstalled?"installed":""}" data-id="${a[0]}">${isInstalled?"Installed":"Install"}</button>
      </div>
    </article>`;
  }).join("");

  appsEl.querySelectorAll(".install").forEach(b => b.onclick = () => install(b.dataset.id));
}

async function install(id) {
  const app = apps.find(a => a[0] === id);
  if (!app) return;
  if (installed.has(id)) {
    showToast(`${app[1]} is already installed`);
    return;
  }

  // Optional backend integration. The web UI remains functional without it.
  try {
    const res = await fetch(`/api/apps/${encodeURIComponent(id)}/install`, {
      method: "POST",
      headers: {"Content-Type":"application/json"}
    });
    if (!res.ok) throw new Error("backend unavailable");
    installed.add(id);
    persist();
    render();
    showToast(`Installing ${app[1]}…`);
  } catch {
    showToast(`Connect a COD++ container to install ${app[1]}`);
  }
}

function persist() {
  localStorage.setItem("codpp-installed", JSON.stringify([...installed]));
}

let toastTimer;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

searchEl.addEventListener("input", e => { query=e.target.value; render(); });

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(()=>{});
}

renderCategories();
render();
