#!/bin/bash
set -e
mkdir -p /data /tmp/runtime-cod
chown -R cod:cod /data /tmp/runtime-cod
export DISPLAY=:99
export HOME=/home/cod
export XDG_RUNTIME_DIR=/tmp/runtime-cod

Xvfb :99 -screen 0 1600x1000x24 -ac +extension GLX +render -noreset >/data/xvfb.log 2>&1 &
XVFB_PID=$!
sleep 2

su -s /bin/bash cod -c 'DISPLAY=:99 XDG_RUNTIME_DIR=/tmp/runtime-cod dbus-run-session -- startxfce4 >/data/xfce.log 2>&1' &
XFCE_PID=$!
sleep 5

if [ -n "$CODPP_VNC_PASSWORD" ]; then
  x11vnc -display :99 -rfbport 5900 -forever -shared -rfbauth /data/vnc.pass -localhost >/data/x11vnc.log 2>&1 &
else
  x11vnc -display :99 -rfbport 5900 -forever -shared -nopw -localhost >/data/x11vnc.log 2>&1 &
fi
VNC_PID=$!

if [ -n "$CODPP_VNC_PASSWORD" ]; then
  x11vnc -storepasswd "$CODPP_VNC_PASSWORD" /data/vnc.pass >/dev/null
fi

websockify --web=/usr/share/novnc 6080 127.0.0.1:5900 >/data/websockify.log 2>&1 &
WEBSOCKIFY_PID=$!

cleanup() { kill $WEBSOCKIFY_PID $VNC_PID $XFCE_PID $XVFB_PID 2>/dev/null || true; }
trap cleanup EXIT INT TERM
node server/index.mjs
