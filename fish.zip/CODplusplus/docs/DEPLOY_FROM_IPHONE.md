# Deploy COD++ from an iPhone/iPad

## 1. GitHub

Create an empty repository on GitHub, then use **Add file → Upload files** to upload the contents of this project. You want `Dockerfile`, `render.yaml`, `server/`, `web/`, `container/`, and the other files at the repository root.

Do not upload `.env` files containing real secrets.

## 2. Render

Open Render in Safari and create a new Web Service connected to the GitHub repository.

Choose the Docker runtime. The included Dockerfile installs the Linux desktop, noVNC, the COD++ API, and the web interface.

Set:

- `NODE_ENV` = `production`
- `CODPP_TOKEN` = your private COD++ API token
- `CODPP_VNC_PASSWORD` = your private Linux desktop password

Add a persistent disk mounted at `/data`.

## 3. Open COD++

After the deployment becomes live, open the Render service URL in Safari.

COD++ will ask for the API token. After authentication, use:

- **App Store** — install software
- **Linux Desktop** — open the cloud Linux GUI
- **Files** — see the persistent-storage area
- **Settings** — change the API token

The Linux desktop's noVNC page will ask for the VNC password.
