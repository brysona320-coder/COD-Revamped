export type Category =
  | "browser"
  | "development"
  | "utility"
  | "creative"
  | "productivity"
  | "networking"
  | "gaming";

export interface AppDefinition {
  id: string;
  name: string;
  category: Category;
  description: string;
  commands: string[];
  launch?: string;
  notes?: string;
}

const apt = (pkg: string): string[] => [`sudo apt-get update`, `sudo apt-get install -y ${pkg}`];

export const APPS: AppDefinition[] = [
  { id:"firefox", name:"Firefox", category:"browser", description:"Mozilla web browser.", commands:apt("firefox"), launch:"firefox" },
  { id:"chromium", name:"Chromium", category:"browser", description:"Open-source Chromium browser.", commands:apt("chromium-browser || chromium"), launch:"chromium" },
  { id:"brave", name:"Brave", category:"browser", description:"Privacy-focused Chromium browser.", commands:apt("brave-browser"), launch:"brave-browser", notes:"Requires a repository/package source that provides brave-browser." },

  { id:"vscode", name:"VS Code", category:"development", description:"Full-featured source-code editor.", commands:apt("code"), launch:"code", notes:"Requires a repository/package source that provides code." },
  { id:"vscodium", name:"VSCodium", category:"development", description:"Community-built VS Code binaries.", commands:apt("codium"), launch:"codium" },
  { id:"git", name:"Git", category:"development", description:"Distributed version control.", commands:apt("git") },
  { id:"gh", name:"GitHub CLI", category:"development", description:"GitHub from the terminal.", commands:apt("gh") },
  { id:"nodejs", name:"Node.js", category:"development", description:"JavaScript runtime and npm ecosystem.", commands:apt("nodejs npm") },
  { id:"python", name:"Python", category:"development", description:"Python 3 and pip.", commands:apt("python3 python3-pip python3-venv") },
  { id:"java", name:"Java", category:"development", description:"OpenJDK development environment.", commands:apt("default-jdk") },
  { id:"gcc", name:"GCC/G++", category:"development", description:"C and C++ compiler toolchain.", commands:apt("build-essential") },
  { id:"clang", name:"Clang", category:"development", description:"LLVM C/C++ compiler.", commands:apt("clang") },
  { id:"rust", name:"Rust", category:"development", description:"Rust compiler and Cargo.", commands:[`curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y`] },
  { id:"go", name:"Go", category:"development", description:"Go programming language.", commands:apt("golang") },
  { id:"neovim", name:"Neovim", category:"development", description:"Modern terminal editor.", commands:apt("neovim"), launch:"nvim" },
  { id:"tmux", name:"tmux", category:"development", description:"Terminal multiplexer.", commands:apt("tmux") },

  { id:"btop", name:"btop", category:"utility", description:"Interactive system monitor.", commands:apt("btop"), launch:"btop" },
  { id:"htop", name:"htop", category:"utility", description:"Interactive process viewer.", commands:apt("htop"), launch:"htop" },
  { id:"ripgrep", name:"ripgrep", category:"utility", description:"Fast recursive text search.", commands:apt("ripgrep") },
  { id:"fd", name:"fd", category:"utility", description:"Fast user-friendly find alternative.", commands:apt("fd-find") },
  { id:"tree", name:"tree", category:"utility", description:"Directory tree viewer.", commands:apt("tree") },
  { id:"jq", name:"jq", category:"utility", description:"Command-line JSON processor.", commands:apt("jq") },
  { id:"unzip", name:"Unzip", category:"utility", description:"ZIP archive utility.", commands:apt("unzip") },
  { id:"p7zip", name:"7-Zip", category:"utility", description:"Archive utility.", commands:apt("p7zip-full") },
  { id:"curl", name:"curl", category:"utility", description:"HTTP and transfer utility.", commands:apt("curl") },
  { id:"wget", name:"wget", category:"utility", description:"Command-line downloader.", commands:apt("wget") },

  { id:"gimp", name:"GIMP", category:"creative", description:"Image editor.", commands:apt("gimp"), launch:"gimp" },
  { id:"krita", name:"Krita", category:"creative", description:"Digital painting application.", commands:apt("krita"), launch:"krita" },
  { id:"inkscape", name:"Inkscape", category:"creative", description:"Vector graphics editor.", commands:apt("inkscape"), launch:"inkscape" },
  { id:"blender", name:"Blender", category:"creative", description:"3D creation suite.", commands:apt("blender"), launch:"blender" },
  { id:"audacity", name:"Audacity", category:"creative", description:"Audio editor and recorder.", commands:apt("audacity"), launch:"audacity" },
  { id:"kdenlive", name:"Kdenlive", category:"creative", description:"Non-linear video editor.", commands:apt("kdenlive"), launch:"kdenlive" },
  { id:"obs", name:"OBS Studio", category:"creative", description:"Screen recording and live production.", commands:apt("obs-studio"), launch:"obs" },

  { id:"libreoffice", name:"LibreOffice", category:"productivity", description:"Office suite.", commands:apt("libreoffice") },
  { id:"vlc", name:"VLC", category:"productivity", description:"Media player.", commands:apt("vlc"), launch:"vlc" },
  { id:"okular", name:"Okular", category:"productivity", description:"PDF/document viewer.", commands:apt("okular"), launch:"okular" },

  { id:"wireshark", name:"Wireshark", category:"networking", description:"Network protocol analyzer.", commands:apt("wireshark"), launch:"wireshark", notes:"Use only on networks/devices you are authorized to analyze." },
  { id:"nmap", name:"Nmap", category:"networking", description:"Network discovery and auditing utility.", commands:apt("nmap"), notes:"Use only on systems you are authorized to test." },
  { id:"openssh", name:"OpenSSH", category:"networking", description:"SSH client/server tools.", commands:apt("openssh-client") },
  { id:"traceroute", name:"Traceroute", category:"networking", description:"Network path diagnostic.", commands:apt("traceroute") },
  { id:"dnsutils", name:"DNS Utilities", category:"networking", description:"DNS lookup tools.", commands:apt("dnsutils") },

  { id:"prismlauncher", name:"Prism Launcher", category:"gaming", description:"Minecraft launcher.", commands:apt("prismlauncher"), launch:"prismlauncher" },
  { id:"heroic", name:"Heroic Games Launcher", category:"gaming", description:"Game launcher for supported stores.", commands:apt("heroic"), launch:"heroic" },
  { id:"lutris", name:"Lutris", category:"gaming", description:"Game launcher/manager.", commands:apt("lutris"), launch:"lutris" },
  { id:"wine", name:"Wine", category:"gaming", description:"Windows compatibility layer.", commands:apt("wine"), notes:"GUI/game compatibility depends on the container." }
];

export function categories(): Category[] {
  return ["browser","development","utility","creative","productivity","networking","gaming"];
}

export function searchApps(query: string): AppDefinition[] {
  const q = query.trim().toLowerCase();
  if (!q) return APPS;
  return APPS.filter(a =>
    `${a.id} ${a.name} ${a.description} ${a.category}`.toLowerCase().includes(q)
  );
}
