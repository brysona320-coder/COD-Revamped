/**
 * COD++ web App Store backend contract.
 *
 * POST /api/apps/:id/install
 * Body: {}
 *
 * The server must:
 * 1. Validate the ID against APPS.
 * 2. Run only the trusted install command(s) from APPS.
 * 3. Return JSON such as { "ok": true, "id": "firefox" }.
 *
 * Never execute a shell command supplied by the browser.
 *
 * A production deployment should also add authentication/authorization,
 * rate limiting, CSRF protection where applicable, and an install queue.
 */
export interface InstallResponse {
  ok: boolean;
  id: string;
  message?: string;
}
