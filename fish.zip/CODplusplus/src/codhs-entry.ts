/**
 * Optional CodeHS adapter.
 *
 * The original COD project is launched from CodeHS Sandbox and imports
 * a package that creates the container computer. CodeHS documents that
 * Sandbox programs can run in the browser and can be forked/shared.
 *
 * Because the exact current runtime API of the original `gadidae` package
 * is external to this repository, this adapter deliberately keeps the
 * COD++ catalog/installer independent from that API.
 *
 * Adapt this file to the runtime exposed by your chosen CodeHS container
 * package. Do not put privileged host operations here.
 */
export const COD_PLUS_PLUS = {
  name: "COD++",
  version: "1.0.0",
  entrypoint: "src/index.ts"
};
