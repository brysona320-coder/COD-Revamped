import { exec } from "node:child_process";
import { promisify } from "node:util";
import type { AppDefinition } from "./catalog/apps.js";

const run = promisify(exec);

export interface InstallOptions {
  dryRun?: boolean;
  log?: (line: string) => void;
}

export async function commandExists(command: string): Promise<boolean> {
  try {
    await run(`command -v ${command}`);
    return true;
  } catch {
    return false;
  }
}

export async function installApp(app: AppDefinition, options: InstallOptions = {}): Promise<boolean> {
  const log = options.log ?? console.log;
  log(`\n==> ${app.name}`);
  if (app.notes) log(`Note: ${app.notes}`);

  for (const command of app.commands) {
    log(`$ ${command}`);
    if (options.dryRun) continue;

    try {
      const result = await run(command, { maxBuffer: 1024 * 1024 * 10 });
      if (result.stdout.trim()) log(result.stdout.trim());
      if (result.stderr.trim()) log(result.stderr.trim());
    } catch (error: any) {
      log(`ERROR: ${error?.message ?? String(error)}`);
      return false;
    }
  }

  log(`✓ ${app.name} finished`);
  return true;
}
