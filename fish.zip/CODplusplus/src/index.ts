import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { APPS, categories, searchApps, type AppDefinition } from "./catalog/apps.js";
import { installApp } from "./installer.js";

const rl = readline.createInterface({ input, output });

function printApps(apps: AppDefinition[]) {
  if (!apps.length) {
    console.log("No matching apps.");
    return;
  }
  for (const [i, a] of apps.entries()) {
    console.log(`${String(i + 1).padStart(2)}. ${a.name.padEnd(28)} ${a.category.padEnd(14)} ${a.description}`);
  }
}

async function main() {
  console.log(`
╔════════════════════════════════════════════╗
║                 COD++                       ║
║  CodeHS-container app manager               ║
╚════════════════════════════════════════════╝
`);

  while (true) {
    console.log("\n1) Browse all apps");
    console.log("2) Search apps");
    console.log("3) Browse category");
    console.log("4) Install selected apps");
    console.log("5) Dry-run selected apps");
    console.log("6) Quit");

    const choice = (await rl.question("> ")).trim();

    if (choice === "1") {
      printApps(APPS);
    } else if (choice === "2") {
      const q = await rl.question("Search: ");
      printApps(searchApps(q));
    } else if (choice === "3") {
      console.log(categories().map((x, i) => `${i + 1}) ${x}`).join("\n"));
      const n = Number(await rl.question("> "));
      const cat = categories()[n - 1];
      if (cat) printApps(APPS.filter(a => a.category === cat));
    } else if (choice === "4" || choice === "5") {
      printApps(APPS);
      const raw = await rl.question("Enter app numbers separated by commas: ");
      const selected = raw.split(",")
        .map(x => Number(x.trim()) - 1)
        .filter(i => Number.isInteger(i) && i >= 0 && i < APPS.length)
        .map(i => APPS[i]);

      if (!selected.length) {
        console.log("Nothing selected.");
        continue;
      }

      console.log(`\nSelected: ${selected.map(a => a.name).join(", ")}`);
      const confirm = (await rl.question("Continue? [y/N] ")).toLowerCase();
      if (confirm !== "y") continue;

      for (const app of selected) {
        await installApp(app, { dryRun: choice === "5" });
      }
    } else if (choice === "6" || choice.toLowerCase() === "q") {
      break;
    }
  }

  rl.close();
}

main().catch(err => {
  console.error(err);
  rl.close();
  process.exit(1);
});
