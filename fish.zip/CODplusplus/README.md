# COD++ Cloud Desktop

COD++ is a browser-based Linux desktop and software center designed to work from an iPhone, iPad, or desktop browser.

## What this version does

- macOS-style COD++ web desktop
- App Store with a large catalog
- One-click installation into the cloud Linux container
- Graphical Linux desktop streamed through noVNC
- Launch installed graphical apps from the App Store
- Persistent `/data` storage for user files and install records
- Docker deployment
- Render Blueprint configuration
- No terminal commands are required for the **deployment process** when using Render's dashboard

## Important architecture note

The iPhone/iPad is the display and control device. Linux applications run in the cloud container. iOS does not execute the Linux GUI binaries itself.

This repository intentionally does **not** expose an arbitrary shell-command API. The server accepts only catalog app IDs and maps them to trusted installation/launch commands.

## Deploy from an iPhone/iPad

The easiest path is GitHub + Render:

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository using GitHub's website.
3. In Render, create a new **Web Service** from the GitHub repository.
4. Choose **Docker** as the runtime. Render can build directly from the included `Dockerfile`.
5. Set these environment variables:
   - `NODE_ENV` = `production`
   - `CODPP_TOKEN` = a long random access token you create
   - `CODPP_VNC_PASSWORD` = a separate strong password for the Linux desktop
6. Attach a persistent disk mounted at `/data`.
7. Deploy.
8. Open the resulting Render URL on your iPhone.
9. Enter the `CODPP_TOKEN` when COD++ asks for it.
10. Open **Linux Desktop** and enter the VNC password when noVNC asks.

The included `render.yaml` contains the service configuration as a starting point.

## Persistence limitation

The persistent disk protects files and COD++ installation records. Linux system packages installed at runtime are still part of the container filesystem, so a full container rebuild/redeploy can require those packages to be installed again. For a production version, the next step would be baking the most-used apps into the Docker image or maintaining a custom image.

## Local development

If you later have access to a computer with Docker, `docker compose` can be added around the same container. It is not required for the iPhone-only deployment flow.
