import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import httpProxy from 'http-proxy';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const WEB = path.join(ROOT, 'web');
const DATA = process.env.CODPP_DATA || '/data';
const PORT = Number(process.env.PORT || 10000);
const TOKEN = process.env.CODPP_TOKEN || '';
const VNC_PASSWORD = process.env.CODPP_VNC_PASSWORD || '';
const proxy = httpProxy.createProxyServer({ target: 'http://127.0.0.1:6080', ws: true });

const apps = JSON.parse(fs.readFileSync(path.join(ROOT, 'server', 'catalog.json'), 'utf8'));
const appMap = new Map(apps.map(a => [a.id, a]));
const stateFile = path.join(DATA, 'installed.json');
fs.mkdirSync(DATA, { recursive: true });

function readState() {
  try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { return {}; }
}
function writeState(s) { fs.writeFileSync(stateFile, JSON.stringify(s, null, 2)); }
function authorized(req) {
  if (!TOKEN) return process.env.NODE_ENV !== 'production';
  return req.headers.authorization === `Bearer ${TOKEN}`;
}
function json(res, status, body) {
  const out = JSON.stringify(body);
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(out);
}
function safePath(urlPath) {
  const clean = decodeURIComponent(urlPath.split('?')[0]);
  const rel = clean === '/' ? '/desktop/index.html' : clean;
  const full = path.normalize(path.join(WEB, rel));
  return full.startsWith(WEB) ? full : null;
}
function mime(file) {
  return ({'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'})[path.extname(file)] || 'application/octet-stream';
}
function serveStatic(req, res) {
  const file = safePath(req.url || '/');
  if (!file) return json(res, 403, {error:'Forbidden'});
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return json(res, 404, {error:'Not found'});
    res.writeHead(200, {'Content-Type':mime(file), 'Cache-Control': file.endsWith('.html') ? 'no-store' : 'public, max-age=3600'});
    fs.createReadStream(file).pipe(res);
  });
}
function commandExists(command) {
  return new Promise(resolve => execFile('sh', ['-lc', `command -v ${command}`], err => resolve(!err)));
}
function runShell(command, log) {
  return new Promise(resolve => {
    log(`$ ${command}`);
    const p = spawn('sh', ['-lc', command], {env:{...process.env, HOME:'/home/cod', DISPLAY:':99', XDG_RUNTIME_DIR:'/tmp/runtime-cod'}, stdio:['ignore','pipe','pipe']});
    p.stdout.on('data', d => log(String(d).trimEnd()));
    p.stderr.on('data', d => log(String(d).trimEnd()));
    p.on('close', code => resolve(code === 0));
  });
}
async function install(id) {
  const app = appMap.get(id);
  if (!app) throw new Error('Unknown app');
  const logs = [];
  const log = x => logs.push(x);
  for (const command of app.install) {
    if (!(await runShell(command, log))) return {ok:false, logs};
  }
  const state = readState(); state[id] = {installed:true, installedAt:new Date().toISOString()}; writeState(state);
  return {ok:true, logs};
}
function launch(id) {
  const app = appMap.get(id);
  const state = readState();
  if (!state[id]?.installed) throw new Error('App is not installed');
  if (!app?.launch) throw new Error('This app does not have a graphical launcher');
  const child = spawn('sh', ['-lc', app.launch], {detached:true, stdio:'ignore', env:{...process.env, HOME:'/home/cod', USER:'cod', DISPLAY:':99', XDG_RUNTIME_DIR:'/tmp/runtime-cod', LIBGL_ALWAYS_SOFTWARE:'1'}});
  child.unref();
}
function setupVncPassword() {
  if (!VNC_PASSWORD) return;
  const dir = path.join(DATA, '.vnc'); fs.mkdirSync(dir, {recursive:true});
  execFile('x11vnc', ['-storepasswd', VNC_PASSWORD, path.join(dir,'passwd')], () => {});
}

const server = http.createServer(async (req,res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/health') return json(res, 200, {ok:true, service:'COD++'});
  if (url.pathname === '/api/apps' && req.method === 'GET') {
    if (!authorized(req)) return json(res,401,{error:'Unauthorized'});
    const state = readState();
    return json(res,200,apps.map(a=>({...a, installed:Boolean(state[a.id]?.installed)})));
  }
  const m = url.pathname.match(/^\/api\/apps\/([^/]+)\/(install|launch)$/);
  if (m && req.method === 'POST') {
    if (!authorized(req)) return json(res,401,{error:'Unauthorized'});
    const id = decodeURIComponent(m[1]);
    if (!appMap.has(id)) return json(res,404,{error:'Unknown app'});
    try {
      if (m[2] === 'install') {
        const result = await install(id);
        return json(res,result.ok ? 200 : 500,result);
      }
      launch(id); return json(res,200,{ok:true,launched:id});
    } catch (e) { return json(res,500,{error:e.message}); }
  }
  if (url.pathname === '/api/state' && req.method === 'GET') {
    if (!authorized(req)) return json(res,401,{error:'Unauthorized'});
    return json(res,200,readState());
  }
  if (url.pathname === '/vnc' || url.pathname === '/vnc/') return serveVncPage(res);
  if (url.pathname.startsWith('/vnc/')) return serveNoVncAsset(req,res);
  serveStatic(req,res);
});

function serveNoVncAsset(req,res) {
  const rel = decodeURIComponent((req.url||'').split('?')[0]).replace(/^\/vnc\//,'');
  const base = '/usr/share/novnc';
  const file = path.normalize(path.join(base, rel));
  if (!file.startsWith(base) || !fs.existsSync(file)) return json(res,404,{error:'noVNC asset not found'});
  const st=fs.statSync(file); if(!st.isFile()) return json(res,404,{error:'Not found'});
  res.writeHead(200,{'Content-Type':mime(file),'Cache-Control':'public, max-age=3600'});
  return fs.createReadStream(file).pipe(res);
}
function serveVncPage(res) {
  const candidates=['/usr/share/novnc/vnc.html','/usr/share/novnc/vnc_lite.html'];
  const file=candidates.find(f=>fs.existsSync(f));
  if (!file) return json(res,503,{error:'noVNC is not installed'});
  let html=fs.readFileSync(file,'utf8');
  html=html.replace('</head>', '<style>html,body{background:#080b12}</style></head>');
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(html);
}
server.on('upgrade',(req,socket,head)=>{
  if ((req.url||'').startsWith('/websockify') || (req.url||'').startsWith('/vnc/websockify')) { req.url=req.url.replace(/^\/vnc/, ''); return proxy.ws(req,socket,head); }
  socket.destroy();
});

server.listen(PORT,'0.0.0.0',()=>console.log(`COD++ listening on 0.0.0.0:${PORT}`));
setupVncPassword();
